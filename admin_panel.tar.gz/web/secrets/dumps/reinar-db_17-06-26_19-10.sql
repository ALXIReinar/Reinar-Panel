--
-- PostgreSQL database dump
--

\restrict b4sisJ0fERkDXZXTWVNaIR3GAkD2gqRxHTuHCgj8FC9ZgN4f4m6qAmdTijxcakU

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

-- Started on 2026-06-17 19:10:32

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 251 (class 1259 OID 517159)
-- Name: sub_nodes_operations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_nodes_operations (
    id smallint NOT NULL,
    title character varying(20) NOT NULL
);


ALTER TABLE public.sub_nodes_operations OWNER TO postgres;

--
-- TOC entry 250 (class 1259 OID 517158)
-- Name: add_core_proto_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sub_nodes_operations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.add_core_proto_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 216 (class 1259 OID 516585)
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    id bigint NOT NULL,
    date_register date DEFAULT (now())::date,
    passw character varying(97) NOT NULL,
    login character varying(128) NOT NULL
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 516823)
-- Name: node_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.node_statuses (
    id smallint NOT NULL,
    name character varying(30) NOT NULL
);


ALTER TABLE public.node_statuses OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 516822)
-- Name: node_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.node_statuses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.node_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 227 (class 1259 OID 516865)
-- Name: nodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nodes (
    id smallint NOT NULL,
    ip character varying(45) NOT NULL,
    private_ip character varying(45),
    api_port integer NOT NULL,
    is_active boolean DEFAULT true,
    title text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at time with time zone DEFAULT now(),
    node_name character varying(64)
);


ALTER TABLE public.nodes OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 516814)
-- Name: nodes_protocols; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nodes_protocols (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    proto_id smallint NOT NULL,
    node_id smallint NOT NULL,
    config_path text,
    user_visible boolean DEFAULT false,
    config_link text,
    metrics_port integer,
    title character varying(30) NOT NULL,
    proto_port integer,
    sub_node_address character varying(255)
);


ALTER TABLE public.nodes_protocols OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 516828)
-- Name: nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.nodes_protocols ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.nodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 226 (class 1259 OID 516864)
-- Name: nodes_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.nodes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.nodes_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 247 (class 1259 OID 517102)
-- Name: nodes_protocoles_spec_params_values; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nodes_protocoles_spec_params_values (
    id bigint NOT NULL,
    spec_key_id bigint NOT NULL,
    node_proto_id integer NOT NULL,
    value character varying(512) NOT NULL
);


ALTER TABLE public.nodes_protocoles_spec_params_values OWNER TO postgres;

--
-- TOC entry 246 (class 1259 OID 517101)
-- Name: nodes_protocoles_spec_params_values_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.nodes_protocoles_spec_params_values ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.nodes_protocoles_spec_params_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 241 (class 1259 OID 517048)
-- Name: online_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.online_statuses (
    id smallint NOT NULL,
    title character varying(32) NOT NULL
);


ALTER TABLE public.online_statuses OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 517047)
-- Name: online_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.online_statuses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.online_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 243 (class 1259 OID 517074)
-- Name: templates_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.templates_statuses (
    id smallint NOT NULL,
    name character varying(32) NOT NULL
);


ALTER TABLE public.templates_statuses OWNER TO postgres;

--
-- TOC entry 242 (class 1259 OID 517073)
-- Name: pattern_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.templates_statuses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.pattern_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 255 (class 1259 OID 525262)
-- Name: pay_statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pay_statuses (
    id smallint NOT NULL,
    name character varying(20) NOT NULL
);


ALTER TABLE public.pay_statuses OWNER TO postgres;

--
-- TOC entry 254 (class 1259 OID 525261)
-- Name: pay_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.pay_statuses ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.pay_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 235 (class 1259 OID 516967)
-- Name: payed_subs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payed_subs (
    id bigint NOT NULL,
    sub_plan_id integer NOT NULL,
    user_id bigint NOT NULL,
    is_active boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    expire_date timestamp with time zone,
    status smallint DEFAULT 1,
    is_limited boolean DEFAULT false
);


ALTER TABLE public.payed_subs OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 516966)
-- Name: payed_subs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.payed_subs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payed_subs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 239 (class 1259 OID 517032)
-- Name: proto_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proto_templates (
    id smallint NOT NULL,
    title character varying(32) NOT NULL,
    url_tmp text,
    status smallint DEFAULT 2 NOT NULL,
    is_accepted boolean DEFAULT false,
    reload_core_command character varying(128),
    required_user_data_obj jsonb,
    constant_user_data_obj jsonb DEFAULT '{}'::jsonb,
    api_add_user_script text,
    api_delete_user_script text,
    proto_python_lib character varying(32) DEFAULT ''::character varying,
    flatten_json_users_key character varying(1024),
    flatten_user_identifier_key character varying(128),
    sub_prepare_script text,
    sub_required_libs character varying(512) DEFAULT ''::character varying,
    api_bulk_delete_user_script text,
    metrics_parser_code text,
    metrics_command character varying(256),
    add_script_custom_params jsonb,
    delete_script_custom_params jsonb,
    bulk_delete_script_custom_params jsonb,
    api_metrics_script text,
    api_bulk_add_user_script text,
    bulk_add_script_custom_params jsonb
);


ALTER TABLE public.proto_templates OWNER TO postgres;

--
-- TOC entry 238 (class 1259 OID 517031)
-- Name: proto_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.proto_templates ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.proto_templates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 218 (class 1259 OID 516768)
-- Name: protocols; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.protocols (
    id smallint NOT NULL,
    name character varying(100) NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    tmp_id smallint NOT NULL
);


ALTER TABLE public.protocols OWNER TO postgres;

--
-- TOC entry 5153 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE protocols; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.protocols IS 'Пул поддерживаемых VPN протоколов';


--
-- TOC entry 5154 (class 0 OID 0)
-- Dependencies: 218
-- Name: COLUMN protocols.name; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.protocols.name IS 'Название протокола (xray, wireguard, openvpn и т.д.)';


--
-- TOC entry 220 (class 1259 OID 516777)
-- Name: protocols_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.protocols_commands (
    id bigint NOT NULL,
    proto_id smallint NOT NULL,
    cmd_title character varying(200) NOT NULL,
    command text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    admin_id bigint
);


ALTER TABLE public.protocols_commands OWNER TO postgres;

--
-- TOC entry 5155 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE protocols_commands; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.protocols_commands IS 'CLI команды для управления протоколами';


--
-- TOC entry 5156 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN protocols_commands.proto_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.protocols_commands.proto_id IS 'ID протокола';


--
-- TOC entry 5157 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN protocols_commands.cmd_title; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.protocols_commands.cmd_title IS 'Название команды (add_user, remove_user, restart и т.д.)';


--
-- TOC entry 5158 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN protocols_commands.command; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.protocols_commands.command IS 'Полная CLI команда для выполнения. Валидация не производится - ответственность администратора';


--
-- TOC entry 221 (class 1259 OID 516813)
-- Name: protocols_commands_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.protocols_commands ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.protocols_commands_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 219 (class 1259 OID 516776)
-- Name: protocols_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.protocols ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.protocols_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 249 (class 1259 OID 517137)
-- Name: remote_execute_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.remote_execute_history (
    id bigint NOT NULL,
    status smallint NOT NULL,
    command character varying(1024) NOT NULL,
    stdout text,
    stderr text,
    exit_code integer DEFAULT 1,
    exception_text text,
    node_proto_id integer,
    api_port integer,
    private_ip character varying(45),
    created_at timestamp with time zone DEFAULT now(),
    status_code smallint DEFAULT 100,
    node_success boolean DEFAULT false,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.remote_execute_history OWNER TO postgres;

--
-- TOC entry 248 (class 1259 OID 517136)
-- Name: remote_execute_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.remote_execute_history ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.remote_execute_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 215 (class 1259 OID 516544)
-- Name: sessions_admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions_admins (
    session_id text NOT NULL,
    admin_id bigint NOT NULL,
    iat timestamp with time zone NOT NULL,
    exp timestamp with time zone NOT NULL,
    refresh_token character varying(97) NOT NULL,
    user_agent character varying(200),
    ip character varying(45) NOT NULL
);


ALTER TABLE public.sessions_admins OWNER TO postgres;

--
-- TOC entry 253 (class 1259 OID 517165)
-- Name: sub_nodes_outbox; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_nodes_outbox (
    id bigint NOT NULL,
    user_uuid character varying(36) NOT NULL,
    tg_username character varying(32) NOT NULL,
    sub_node_id integer NOT NULL,
    order_id bigint NOT NULL,
    is_retried boolean DEFAULT false,
    operation smallint NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.sub_nodes_outbox OWNER TO postgres;

--
-- TOC entry 252 (class 1259 OID 517164)
-- Name: sub_nodes_outbox_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sub_nodes_outbox ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sub_nodes_outbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 233 (class 1259 OID 516940)
-- Name: sub_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sub_plans (
    id integer NOT NULL,
    traffic_limit_day bigint DEFAULT '-1'::integer,
    cost bigint DEFAULT 0,
    is_active boolean,
    ttl_days smallint,
    title character varying(25) NOT NULL,
    description character varying(200)
);


ALTER TABLE public.sub_plans OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 516939)
-- Name: sub_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sub_plans ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sub_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 245 (class 1259 OID 517087)
-- Name: template_spec_params; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.template_spec_params (
    id bigint NOT NULL,
    key text NOT NULL,
    tmp_id smallint NOT NULL
);


ALTER TABLE public.template_spec_params OWNER TO postgres;

--
-- TOC entry 244 (class 1259 OID 517086)
-- Name: template_spec_params_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.template_spec_params ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.template_spec_params_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 231 (class 1259 OID 516929)
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    tg_id bigint,
    b64_id character varying(64),
    traffic_used_day_mb bigint DEFAULT 0,
    tg_username character varying(32),
    uuid character varying(36) NOT NULL,
    online_status smallint DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 516593)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.admins ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 516928)
-- Name: users_id_seq1; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 236 (class 1259 OID 517004)
-- Name: vnodes_sub_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vnodes_sub_plans (
    id integer NOT NULL,
    node_proto_id integer NOT NULL,
    sub_plan_id integer NOT NULL
);


ALTER TABLE public.vnodes_sub_plans OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 517013)
-- Name: vnodes_sub_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.vnodes_sub_plans ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.vnodes_sub_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 229 (class 1259 OID 516918)
-- Name: whitelist_commands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.whitelist_commands (
    id integer NOT NULL,
    command character varying(1000) NOT NULL,
    is_active boolean DEFAULT true
);


ALTER TABLE public.whitelist_commands OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 516917)
-- Name: whitelist_commands_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.whitelist_commands ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.whitelist_commands_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 5108 (class 0 OID 516585)
-- Dependencies: 216
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.admins OVERRIDING SYSTEM VALUE VALUES (6, '2026-05-13', '$argon2id$v=19$m=65536,t=3,p=4$MwbgXGtNCSHk/J+zthYCwA$B61h17P3bntVOGcDp25xb/g3BmrBIOFsWQ+Qd9jznv4', 'admin');


--
-- TOC entry 5116 (class 0 OID 516823)
-- Dependencies: 224
-- Data for Name: node_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.node_statuses OVERRIDING SYSTEM VALUE VALUES (1, 'Vpn Worker');
INSERT INTO public.node_statuses OVERRIDING SYSTEM VALUE VALUES (2, 'Balancer');


--
-- TOC entry 5119 (class 0 OID 516865)
-- Dependencies: 227
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.nodes OVERRIDING SYSTEM VALUE VALUES (1, '194.48.143.33', '10.0.0.1', 8200, true, 'test', '2026-05-14 16:54:24.278992+03', '16:54:24.278992+03', 'test');


--
-- TOC entry 5139 (class 0 OID 517102)
-- Dependencies: 247
-- Data for Name: nodes_protocoles_spec_params_values; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.nodes_protocoles_spec_params_values OVERRIDING SYSTEM VALUE VALUES (16, 1, 2, 'Secret_epta');
INSERT INTO public.nodes_protocoles_spec_params_values OVERRIDING SYSTEM VALUE VALUES (1, 2, 2, 'xtls-rprx-vision');


--
-- TOC entry 5114 (class 0 OID 516814)
-- Dependencies: 222
-- Data for Name: nodes_protocols; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.nodes_protocols OVERRIDING SYSTEM VALUE VALUES (1, '2026-05-14 17:54:29.124711+03', '2026-05-14 17:54:29.124711+03', 2, 1, NULL, false, NULL, NULL, '1', NULL, NULL);
INSERT INTO public.nodes_protocols OVERRIDING SYSTEM VALUE VALUES (2, '2026-05-14 17:54:46.522213+03', '2026-05-14 17:54:46.522213+03', 2, 1, '/usr/local/etc/xray/config.json', true, 'vless://{user_uuid}@three.ascorobot.ru:444?type=grpc&security=reality&pbk=vwvrZq1-XcqXatAhBm0NsfdNA-rmHtHCcY_dYVm_xVg&fp=chrome&sni=ads.x5.ru&sid=7a1d9c1e4b8f2a6d&spx=/&serviceName=grpc&mode=gun#%F0%9F%87%AB%F0%9F%87%AE%20%D0%A4%D0%B8%D0%BD%D0%BB%D1%8F%D0%BD%D0%B4%D0%B8%D1%8F
', 10085, 'Финлянддия', 444, 'three.ascorobot.ru');
INSERT INTO public.nodes_protocols OVERRIDING SYSTEM VALUE VALUES (3, '2026-05-14 17:54:46.522213+03', '2026-05-14 17:54:46.522213+03', 2, 1, 'C:/Users/ALXI/PycharmProjects/ReinarPanel/web/secrets/tcp-vless/vless-tcp-server-metrics.json', false, 'vless://{user_uuid}@three.ascorobot.ru:444?type=grpc&security=reality&pbk=vwvrZq1-XcqXatAhBm0NsfdNA-rmHtHCcY_dYVm_xVg&fp=chrome&sni=ads.x5.ru&sid=7a1d9c1e4b8f2a6d&spx=/&serviceName=grpc&mode=gun#%F0%9F%87%AB%F0%9F%87%AE%20%D0%A4%D0%B8%D0%BD%D0%BB%D1%8F%D0%BD%D0%B4%D0%B8%D1%8F
', 10086, 'Финлянддия', 443, 'three.ascorobot.ru');


--
-- TOC entry 5133 (class 0 OID 517048)
-- Dependencies: 241
-- Data for Name: online_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.online_statuses OVERRIDING SYSTEM VALUE VALUES (1, 'Не подключался');
INSERT INTO public.online_statuses OVERRIDING SYSTEM VALUE VALUES (2, 'Оффлайн');
INSERT INTO public.online_statuses OVERRIDING SYSTEM VALUE VALUES (3, 'Онлайн');


--
-- TOC entry 5147 (class 0 OID 525262)
-- Dependencies: 255
-- Data for Name: pay_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.pay_statuses OVERRIDING SYSTEM VALUE VALUES (1, 'pending');
INSERT INTO public.pay_statuses OVERRIDING SYSTEM VALUE VALUES (2, 'success');
INSERT INTO public.pay_statuses OVERRIDING SYSTEM VALUE VALUES (3, 'expired');


--
-- TOC entry 5127 (class 0 OID 516967)
-- Dependencies: 235
-- Data for Name: payed_subs; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (5, 1, 2, false, '2026-05-27 12:14:47.9044+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (6, 1, 2, false, '2026-05-27 12:15:05.881916+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (7, 1, 2, false, '2026-05-27 12:15:10.440747+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (60, 1, 1, false, '2026-05-29 09:51:58.663218+03', '2029-04-21 14:57:37.660078+03', 2, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (58, 1, 1, false, '2026-05-29 09:41:12.829769+03', '2029-01-31 14:57:37.660078+03', 2, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (56, 1, 1, false, '2026-05-29 08:37:00.693763+03', '2028-11-12 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (54, 1, 1, false, '2026-05-28 15:20:27.145786+03', '2028-08-24 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (53, 1, 1, false, '2026-05-28 15:16:01.819677+03', '2028-06-25 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (52, 1, 1, false, '2026-05-28 15:13:36.532165+03', '2028-04-26 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (26, 1, 1, false, '2026-05-27 14:14:13.821308+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (25, 1, 1, false, '2026-05-27 14:10:11.20303+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (24, 1, 1, false, '2026-05-27 13:55:50.287783+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (23, 1, 1, false, '2026-05-27 13:54:27.298503+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (22, 1, 1, false, '2026-05-27 13:52:01.505173+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (21, 1, 1, false, '2026-05-27 13:51:02.805677+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (20, 1, 1, false, '2026-05-27 12:55:54.003838+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (19, 1, 1, false, '2026-05-27 12:55:05.128523+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (18, 1, 1, false, '2026-05-27 12:52:41.643487+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (17, 1, 1, false, '2026-05-27 12:52:14.196219+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (16, 1, 1, false, '2026-05-27 12:51:04.355696+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (15, 1, 1, false, '2026-05-27 12:50:32.538211+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (14, 1, 1, false, '2026-05-27 12:50:06.764449+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (13, 1, 1, false, '2026-05-27 12:49:03.600859+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (12, 1, 1, false, '2026-05-27 12:46:43.998878+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (11, 1, 1, false, '2026-05-27 12:24:15.204148+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (10, 1, 1, false, '2026-05-27 12:21:38.890746+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (9, 1, 1, false, '2026-05-27 12:20:39.740708+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (3, 1, 1, false, '2026-05-27 12:13:20.516564+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (2, 1, 1, false, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (48, 1, 1, false, '2026-05-27 15:50:03.401153+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (47, 1, 1, false, '2026-05-27 15:49:04.273643+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (72, 1, 1, false, '2026-05-29 10:59:11.026912+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (37, 1, 1, false, '2026-05-27 14:57:37.660078+03', '2026-06-26 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (36, 1, 1, false, '2026-05-27 14:54:49.358603+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (35, 1, 1, false, '2026-05-27 14:45:45.453541+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (62, 1, 1, true, '2026-05-29 10:05:49.409972+03', '2029-07-10 14:57:37.660078+03', 2, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (61, 1, 1, false, '2026-05-29 09:53:05.568055+03', '2029-05-31 14:57:37.660078+03', 2, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (59, 1, 1, false, '2026-05-29 09:47:20.10774+03', '2029-03-12 14:57:37.660078+03', 2, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (57, 1, 1, false, '2026-05-29 08:53:01.943066+03', '2028-12-22 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (55, 1, 1, false, '2026-05-29 08:32:20.397826+03', '2028-10-03 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (51, 1, 1, false, '2026-05-28 15:00:21.037609+03', '2028-02-26 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (50, 1, 1, false, '2026-05-27 15:58:59.604824+03', '2027-12-28 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (49, 1, 1, false, '2026-05-27 15:57:03.391286+03', '2027-11-08 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (46, 1, 1, false, '2026-05-27 15:46:45.661373+03', '2027-09-19 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (45, 1, 1, false, '2026-05-27 15:44:07.319546+03', '2027-07-31 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (44, 1, 1, false, '2026-05-27 15:42:28.71479+03', '2027-06-11 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (43, 1, 1, false, '2026-05-27 15:40:14.399016+03', '2027-04-22 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (42, 1, 1, false, '2026-05-27 15:36:04.084634+03', '2027-03-03 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (41, 1, 1, false, '2026-05-27 15:30:48.160073+03', '2027-01-12 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (40, 1, 1, false, '2026-05-27 15:20:01.902859+03', '2026-11-23 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (39, 1, 1, false, '2026-05-27 15:16:49.139164+03', '2026-10-04 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (38, 1, 1, false, '2026-05-27 15:15:35.335049+03', '2026-08-15 14:57:37.660078+03', 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (34, 1, 1, false, '2026-05-27 14:43:00.478516+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (33, 1, 1, false, '2026-05-27 14:40:05.160499+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (32, 1, 1, false, '2026-05-27 14:35:21.856972+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (31, 1, 1, false, '2026-05-27 14:31:05.840461+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (30, 1, 1, false, '2026-05-27 14:28:20.817366+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (29, 1, 1, false, '2026-05-27 14:23:34.70601+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (28, 1, 1, false, '2026-05-27 14:22:24.432472+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (27, 1, 1, false, '2026-05-27 14:20:00.693054+03', NULL, 1, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (63, 1, 11, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (64, 1, 10, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (65, 1, 9, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (66, 1, 8, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (67, 1, 7, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (68, 1, 6, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (69, 1, 5, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (70, 1, 4, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);
INSERT INTO public.payed_subs OVERRIDING SYSTEM VALUE VALUES (71, 1, 3, true, '2026-05-27 09:51:04.820826+03', '2026-06-26 09:51:04.820826+03', 3, false);


--
-- TOC entry 5131 (class 0 OID 517032)
-- Dependencies: 239
-- Data for Name: proto_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.proto_templates OVERRIDING SYSTEM VALUE VALUES (3, 'shadowshocks', 'ss://{{method_password_base64}}@{{node_ip}}:{{inbounds.0.port}}#{{node_title}}
', 2, false, NULL, NULL, '{}', NULL, NULL, NULL, NULL, NULL, NULL, '', 'async def bulk_delete_users(users_list, node_ip, core_port, custom_params):
    inbound_tag = custom_params.get("inbound_tag", "vless-inbound")
    
    client = xtlsapi.XrayClient(node_ip, core_port)
    
    def _do_bulk():
        success_count = 0
        for u in users_list:
            email = u.get(''tg_username'') or u.get(''email'')
            try:
                client.remove_client(inbound_tag=inbound_tag, email=email)
                success_count += 1
            except Exception as e:
                # Ловим ошибку, если пользователя и так нет в ядре, и продолжаем
                print(f"Пропуск удаления {email}: {e}")
        return success_count
        
    success_count = await asyncio.to_thread(_do_bulk)
    failed_count = len(users_list) - success_count
    
    return {"success": success_count, "failed": failed_count}', NULL, NULL, NULL, NULL, NULL, 'async def get_metrics(node_ip, core_port, custom_params):
    def _do_collect():
        client = xtlsapi.XrayClient(node_ip, core_port)
        return client.stats_query(pattern=''user>>>'', reset=True)
    return await asyncio.to_thread(_do_collect)', NULL, NULL);
INSERT INTO public.proto_templates OVERRIDING SYSTEM VALUE VALUES (2, 'vmess tls ws', 'vmess://', 2, false, NULL, NULL, '{}', NULL, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'async def bulk_add_users(users_list, node_ip, core_port, custom_params):
    inbound_tag = custom_params.get("inbound_tag", "vless-inbound")
    flow = custom_params.get(''flow'', ''xtls-rprx-vision'')
    client = xtlsapi.XrayClient(node_ip, core_port)

    def _do_bulk():
        success_count = 0
        for u in users_list:
            email = u.get(''email'') or u.get(''tg_username'') 
            _id = u.get(''id'')
            try:
                client.add_client(
                    inbound_tag=inbound_tag,
                    user_id_or_password=_id,
                    email=email,
                    flow=flow,
                )
                success_count += 1
            except xtlsapi.exceptions.EmailAlreadyExists: 
                success_count += 1
            except Exception as e:
                # Ловим ошибку, если пользователя и так нет в ядре, и продолжаем
                print(f"Пропуск удаления {email}: {e}")
        return success_count

    success_count = await asyncio.to_thread(_do_bulk)
    failed_count = len(users_list) - success_count

    return {"success": success_count, "failed": failed_count}', NULL);
INSERT INTO public.proto_templates OVERRIDING SYSTEM VALUE VALUES (6, 'Hysteria2 Brutal', 'hysteria2://{user_uuid}@{{node___address}}:123,5000-6000/?insecure=1&obfs=salamander&obfs-password=gawrgura&pinSHA256=deadbeef&sni=www.microsoft.com', 2, true, NULL, NULL, '{}', NULL, NULL, '', NULL, NULL, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO public.proto_templates OVERRIDING SYSTEM VALUE VALUES (1, 'vless_tcp_sni_based', 'vless://{user_uuid}@{{node___address}}:{{inbounds___1___port}}?encryption=none&flow={{flow}}&security={{inbounds___1___streamSettings___security}}&sni={{inbounds___1___streamSettings___realitySettings___serverNames___0}}&fp={{inbounds___1___streamSettings___realitySettings___fingerprint}}&pbk={{pbk}}&sid={{inbounds___1___streamSettings___realitySettings___shortIds___1}}&type={{inbounds___1___streamSettings___network}}#{{node___title}}', 1, false, 'systemctl restart xray', '{"id": "{USER_UUID}", "email": "{USER_TG_USERNAME}"}', '{"flow": "xtls-rprx-vision", "level": 0}', 'async def add_user(user_obj, node_ip, core_port, custom_params):
    # Извлекаем параметры, с фолбеками по умолчанию
    inbound_tag = custom_params.get("inbound_tag", "vless-inbound")
    
    user_uuid = user_obj.get("id")
    email = user_obj.get("email", f"user_{user_uuid[:8]}")
    flow = custom_params.get(''flow'', ''xtls-rprx-vision'')
    
    # Инициализируем клиент (xtlsapi прокинут из global_scope)
    client = xtlsapi.XrayClient(node_ip, core_port)
    
    # Оборачиваем синхронный вызов библиотеки
    def _do_add():
        client.add_client(
            inbound_tag=inbound_tag,
            user_id_or_password=user_uuid,
            email=email,
            flow=flow,
        )
        
    # Выполняем в отдельном пуле потоков без блокировки Event Loop
    try:
        _do_add()
        # await asyncio.to_thread(_do_add)
    except xtlsapi.exceptions.EmailAlreadyExists: # Если пользователь был, увы, это исключение
        return True
    return True', 'async def delete_user(user_obj, node_ip, core_port, custom_params):
    inbound_tag = custom_params.get("inbound_tag", "vless-inbound")
    email = user_obj.get("email", f"user_{user_obj.get(''id'')[:8]}")
    
    client = xtlsapi.XrayClient(node_ip, core_port)
    
    def _do_delete():
        # В Xray удаление всегда происходит по email, а не по UUID
        client.remove_client(
            inbound_tag=inbound_tag, 
            email=email
        )
    try:
        await asyncio.to_thread(_do_delete)
    except xtlsapi.exceptions.EmailNotFound:
        return True
    return True', 'xtlsapi', 'inbounds___1___settings___clients', 'id', 'def prepare_sub(user_uuid: str, config_link: str):
    return config_link.format(user_uuid=user_uuid)', '', 'async def bulk_delete_users(users_list, node_ip, core_port, custom_params):
    inbound_tag = custom_params.get("inbound_tag", "vless-inbound")
    
    client = xtlsapi.XrayClient(node_ip, core_port)
    
    def _do_bulk():
        success_count = 0
        for u in users_list:
            email = u.get(''tg_username'') or u.get(''email'')
            try:
                client.remove_client(inbound_tag=inbound_tag, email=email)
                success_count += 1
            except Exception as e:
                # Ловим ошибку, если пользователя и так нет в ядре, и продолжаем
                print(f"Пропуск удаления {email}: {e}")
        return success_count
        
    success_count = await asyncio.to_thread(_do_bulk)
    failed_count = len(users_list) - success_count
    
    return {"success": success_count, "failed": failed_count}', 'def parse(stdout):
    json_obj = json.loads(stdout)

    traffic_map = defaultdict(int)
    troubles = []

    for user in json_obj[''stat'']:
        tg_username = user.get(''name'')
        if not tg_username:
            troubles.append(user)
            continue

        tg_username = tg_username.split(''>>>'')[1] # Extract username from "user>>>SuperUser>>>traffic>>>downlink"
        traffic_map[tg_username] += int(user.get(''value'', 0)) // 1024 // 1024 # Bytes > MBytes

    users_traffics = [{''tg_username'': username, ''total_mb_used'': used_mb} for username, used_mb in traffic_map.items()]
    return users_traffics, troubles', 'xray api statsquery --server=127.0.0.1:{} -pattern "user>>>" -reset', '{"flow": "xtls-rprx-vision", "inbound_tag": "vless-inbound"}', '{"flow": "xtls-rprx-vision", "inbound_tag": "vless-inbound"}', '{"flow": "xtls-rprx-vision", "inbound_tag": "vless-inbound"}', 'async def get_metrics(node_ip, core_port, custom_params):
    def _do_collect():
        client = xtlsapi.XrayClient(node_ip, core_port)
        return client.stats_query(pattern=''user>>>'', reset=True)
    return await asyncio.to_thread(_do_collect)', 'async def bulk_add_users(users_list, node_ip, core_port, custom_params):
    inbound_tag = custom_params.get("inbound_tag", "vless-inbound")
    flow = custom_params.get(''flow'', ''xtls-rprx-vision'')
    client = xtlsapi.XrayClient(node_ip, core_port)

    def _do_bulk():
        success_count = 0
        for u in users_list:
            email = u.get(''email'') or u.get(''tg_username'') 
            _id = u.get(''id'')
            try:
                client.add_client(
                    inbound_tag=inbound_tag,
                    user_id_or_password=_id,
                    email=email,
                    flow=flow,
                )
                success_count += 1
            except xtlsapi.exceptions.EmailAlreadyExists: 
                success_count += 1
            except Exception as e:
                # Ловим ошибку, если пользователя и так нет в ядре, и продолжаем
                print(f"Пропуск удаления {email}: {e}")
        return success_count

    success_count = await asyncio.to_thread(_do_bulk)
    failed_count = len(users_list) - success_count

    return {"success": success_count, "failed": failed_count}', NULL);


--
-- TOC entry 5110 (class 0 OID 516768)
-- Dependencies: 218
-- Data for Name: protocols; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.protocols OVERRIDING SYSTEM VALUE VALUES (2, 'vless', '2026-05-06 21:11:16.213501', 1);
INSERT INTO public.protocols OVERRIDING SYSTEM VALUE VALUES (9, 'VLESS', '2026-05-13 08:42:03.022118', 1);
INSERT INTO public.protocols OVERRIDING SYSTEM VALUE VALUES (12, 'Hysteria2', '2026-06-15 16:38:10.204135', 6);
INSERT INTO public.protocols OVERRIDING SYSTEM VALUE VALUES (19, 'smess', '2026-06-15 16:40:01.240941', 6);


--
-- TOC entry 5112 (class 0 OID 516777)
-- Dependencies: 220
-- Data for Name: protocols_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (5, 2, 'xray starting', 'systemctl xray', '2026-05-06 22:24:56.219508', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (6, 2, 'xray start', 'systemctl xray', '2026-05-06 22:24:56.219508', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (9, 2, 'xray stop', 'x', '2026-05-06 22:28:38.787582', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (10, 2, 'xray start2', 'x', '2026-05-06 22:28:38.787582', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (11, 2, 'cmd_title', 'command', '2026-05-06 22:36:05.515444', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (12, 2, 'cmd_title', 'command', '2026-05-06 22:36:05.515444', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (21, 2, 'x', 'x', '2026-05-06 23:17:06.157756', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (19, 2, '333', 'string', '2026-05-06 23:13:39.082411', NULL);
INSERT INTO public.protocols_commands OVERRIDING SYSTEM VALUE VALUES (20, 2, 'xxxx', 'string', '2026-05-06 23:13:39.082411', NULL);


--
-- TOC entry 5141 (class 0 OID 517137)
-- Dependencies: 249
-- Data for Name: remote_execute_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (1, 4, 'sudo systemctl restart malicious-service', NULL, NULL, 1, '''stdout''', 1, 1, '127.0.0.1', '2026-06-16 21:17:20.325389+03', 500, false, '2026-06-16 21:17:20.459214+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (2, 4, '(whoami)', NULL, NULL, 1, '''stdout''', 1, 1, '127.0.0.1', '2026-06-16 21:22:38.614316+03', 500, false, '2026-06-16 21:22:38.620955+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (3, 2, 'sudo systemctl restart xray', '', '', 0, NULL, 2, 1, '127.0.0.1', '2026-06-17 16:12:37.844874+03', 200, true, '2026-06-17 16:12:41.53796+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (4, 2, 'ls -la', 'total 40
drwxr-xr-x 4 1000 1000 4096 Jun 17 12:59 .
drwxr-xr-x 4 1000 1000 4096 Jun  2 14:36 ..
-rw-r--r-- 1 1000 1000  337 Jun  2 14:04 .env.example
-rw-r--r-- 1 1000 1000  277 Jun 17 12:59 .env.node.prod
-rw-r--r-- 1 1000 1000 7311 Jun  2 14:04 README.md
drwxrwxrwx 6 root root 4096 Jun  8 16:30 node_client
-rw-r--r-- 1 1000 1000  592 Jun  2 14:04 requirements.txt
-rw-r--r-- 1 1000 1000 2509 Jun  2 14:04 uninstall.sh
drwxr-xr-x 5 1000 1000 4096 Jun  1 15:03 venv
', '', 0, NULL, 3, 18100, '127.0.0.1', '2026-06-17 16:23:01.761539+03', 200, true, '2026-06-17 16:23:01.982856+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (5, 2, 'ls /nonexistent_dir_12345', '', 'ls: cannot access ''/nonexistent_dir_12345'': No such file or directory
', 2, NULL, 3, 18100, '127.0.0.1', '2026-06-17 16:23:14.322802+03', 200, false, '2026-06-17 16:23:14.423364+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (6, 2, 'df -h', 'Filesystem      Size  Used Avail Use% Mounted on
tmpfs            96M  1.2M   95M   2% /run
/dev/sda3       8.8G  7.4G 1012M  89% /
tmpfs           479M     0  479M   0% /dev/shm
tmpfs           5.0M     0  5.0M   0% /run/lock
/dev/sda1       500M  6.1M  493M   2% /boot/efi
tmpfs            96M  4.0K   96M   1% /run/user/0
', '', 0, NULL, 3, 18100, '127.0.0.1', '2026-06-17 16:24:07.398833+03', 200, true, '2026-06-17 16:24:07.506404+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (7, 4, 'nc -l 1234', NULL, NULL, 1, '''stdout''', 3, 18100, '127.0.0.1', '2026-06-17 16:24:22.318046+03', 500, false, '2026-06-17 16:24:52.432542+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (8, 2, 'sudo systemctl status', '● user
    State: degraded
     Jobs: 0 queued
   Failed: 4 units
    Since: Mon 2026-06-08 13:51:37 UTC; 1 week 1 day ago
   CGroup: /
           ├─user.slice 
           │ └─user-0.slice 
           │   ├─session-241.scope 
           │   │ ├─247587 sshd: root@pts/0
           │   │ ├─247671 -bash
           │   │ ├─248881 systemctl status vpn-node-client
           │   │ └─248882 pager
           │   ├─session-252.scope 
           │   │ ├─248689 sshd: root@pts/1
           │   │ └─248751 -bash
           │   ├─session-1.scope 
           │   │ ├─1221 /bin/login -p --
           │   │ └─1568 -bash
           │   └─user@0.service …
           │     └─init.scope 
           │       ├─1560 /lib/systemd/systemd --user
           │       └─1561 (sd-pam)
           ├─init.scope 
           │ └─1 /sbin/init
           └─system.slice 
             ├─containerd.service …
             │ └─990 /usr/bin/containerd
             ├─systemd-networkd.service 
             │ └─779 /lib/systemd/systemd-networkd
             ├─systemd-udevd.service 
             │ └─521 /lib/systemd/systemd-udevd
             ├─cron.service 
             │ └─1208 /usr/sbin/cron -f -P
             ├─docker.service …
             │ └─1205 /usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock
             ├─polkit.service 
             │ └─868 /usr/libexec/polkitd --no-debug
             ├─networkd-dispatcher.service 
             │ └─867 /usr/bin/python3 /usr/bin/networkd-dispatcher --run-startup-triggers
             ├─multipathd.service 
             │ └─518 /sbin/multipathd -d -s
             ├─ModemManager.service 
             │ └─908 /usr/sbin/ModemManager
             ├─systemd-journald.service 
             │ └─480 /lib/systemd/systemd-journald
             ├─unattended-upgrades.service 
             │ └─962 /usr/bin/python3 /usr/share/unattended-upgrades/unattended-upgrade-shutdown --wait-for-signal
             ├─ssh.service 
             │ ├─  1238 sshd: /usr/sbin/sshd -D [listener] 1 of 10-100 startups
             │ └─248890 sshd: [accepted]
             ├─snapd.service 
             │ └─248334 /usr/lib/snapd/snapd
             ├─rsyslog.service 
             │ └─870 /usr/sbin/rsyslogd -n -iNONE
             ├─chrony.service 
             │ ├─1091 /usr/sbin/chronyd -F 1
             │ └─1094 /usr/sbin/chronyd -F 1
             ├─upower.service 
             │ └─1817 /usr/libexec/upowerd
             ├─systemd-resolved.service 
             │ └─878 /lib/systemd/systemd-resolved
             ├─udisks2.service 
             │ └─875 /usr/libexec/udisks2/udisksd
             ├─dbus.service 
             │ └─862 @dbus-daemon --system --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only
             ├─xray.service 
             │ └─248817 /usr/local/bin/xray run -config /usr/local/etc/xray/config.json
             ├─vpn-node-client.service 
             │ ├─248687 /opt/vpn-panel/node/venv/bin/python -m node_client.main
             │ ├─248873 nc -l 1234
             │ ├─248891 /bin/sh -c sudo systemctl status
             │ ├─248892 sudo systemctl status
             │ └─248893 systemctl status
             └─systemd-logind.service 
               └─874 /lib/systemd/systemd-logind
', '', 0, NULL, 3, 18100, '127.0.0.1', '2026-06-17 16:27:47.720327+03', 200, true, '2026-06-17 16:27:47.870715+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (9, 2, 'ps aux', 'USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root           1  0.1  1.1 166432 11272 ?        Ss   Jun08  14:41 /sbin/init
root           2  0.0  0.0      0     0 ?        S    Jun08   0:06 [kthreadd]
root           3  0.0  0.0      0     0 ?        I<   Jun08   0:00 [rcu_gp]
root           4  0.0  0.0      0     0 ?        I<   Jun08   0:00 [rcu_par_gp]
root           5  0.0  0.0      0     0 ?        I<   Jun08   0:00 [slub_flushwq]
root           6  0.0  0.0      0     0 ?        I<   Jun08   0:00 [netns]
root           8  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kworker/0:0H-events_highpri]
root          10  0.0  0.0      0     0 ?        I<   Jun08   0:00 [mm_percpu_wq]
root          11  0.0  0.0      0     0 ?        S    Jun08   0:00 [rcu_tasks_rude_]
root          12  0.0  0.0      0     0 ?        S    Jun08   0:00 [rcu_tasks_trace]
root          13  0.6  0.0      0     0 ?        S    Jun08  89:55 [ksoftirqd/0]
root          14  0.0  0.0      0     0 ?        I    Jun08  10:43 [rcu_sched]
root          15  0.0  0.0      0     0 ?        S    Jun08   0:18 [migration/0]
root          16  0.0  0.0      0     0 ?        S    Jun08   0:00 [idle_inject/0]
root          18  0.0  0.0      0     0 ?        S    Jun08   0:00 [cpuhp/0]
root          19  0.0  0.0      0     0 ?        S    Jun08   0:00 [kdevtmpfs]
root          20  0.0  0.0      0     0 ?        I<   Jun08   0:00 [inet_frag_wq]
root          21  0.0  0.0      0     0 ?        S    Jun08   0:00 [kauditd]
root          22  0.0  0.0      0     0 ?        S    Jun08   0:06 [khungtaskd]
root          23  0.0  0.0      0     0 ?        S    Jun08   0:00 [oom_reaper]
root          24  0.0  0.0      0     0 ?        I<   Jun08   0:00 [writeback]
root          25  0.0  0.0      0     0 ?        S    Jun08   1:55 [kcompactd0]
root          26  0.0  0.0      0     0 ?        SN   Jun08   0:00 [ksmd]
root          27  0.0  0.0      0     0 ?        SN   Jun08   0:00 [khugepaged]
root          73  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kintegrityd]
root          74  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kblockd]
root          75  0.0  0.0      0     0 ?        I<   Jun08   0:00 [blkcg_punt_bio]
root          76  0.0  0.0      0     0 ?        I<   Jun08   0:00 [tpm_dev_wq]
root          77  0.0  0.0      0     0 ?        I<   Jun08   0:00 [ata_sff]
root          78  0.0  0.0      0     0 ?        I<   Jun08   0:00 [md]
root          79  0.0  0.0      0     0 ?        I<   Jun08   0:00 [edac-poller]
root          80  0.0  0.0      0     0 ?        I<   Jun08   0:00 [devfreq_wq]
root          81  0.0  0.0      0     0 ?        S    Jun08   0:00 [watchdogd]
root          83  0.0  0.0      0     0 ?        I<   Jun08   0:40 [kworker/0:1H-kblockd]
root          85  0.0  0.0      0     0 ?        S    Jun08   0:08 [kswapd0]
root          86  0.0  0.0      0     0 ?        S    Jun08   0:00 [ecryptfs-kthrea]
root          88  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kthrotld]
root          89  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/24-pciehp]
root          90  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/25-pciehp]
root          91  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/26-pciehp]
root          92  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/27-pciehp]
root          93  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/28-pciehp]
root          94  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/29-pciehp]
root          95  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/30-pciehp]
root          96  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/31-pciehp]
root          97  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/32-pciehp]
root          98  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/33-pciehp]
root          99  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/34-pciehp]
root         100  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/35-pciehp]
root         101  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/36-pciehp]
root         102  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/37-pciehp]
root         103  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/38-pciehp]
root         104  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/39-pciehp]
root         105  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/40-pciehp]
root         106  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/41-pciehp]
root         107  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/42-pciehp]
root         108  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/43-pciehp]
root         109  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/44-pciehp]
root         110  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/45-pciehp]
root         111  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/46-pciehp]
root         112  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/47-pciehp]
root         113  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/48-pciehp]
root         114  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/49-pciehp]
root         115  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/50-pciehp]
root         116  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/51-pciehp]
root         117  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/52-pciehp]
root         118  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/53-pciehp]
root         119  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/54-pciehp]
root         120  0.0  0.0      0     0 ?        S    Jun08   0:00 [irq/55-pciehp]
root         121  0.0  0.0      0     0 ?        I<   Jun08   0:00 [acpi_thermal_pm]
root         123  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_0]
root         124  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_0]
root         125  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_1]
root         126  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_1]
root         128  0.0  0.0      0     0 ?        I<   Jun08   0:00 [vfio-irqfd-clea]
root         130  0.0  0.0      0     0 ?        I<   Jun08   0:00 [mld]
root         131  0.0  0.0      0     0 ?        I<   Jun08   0:00 [ipv6_addrconf]
root         140  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kstrp]
root         143  0.0  0.0      0     0 ?        I<   Jun08   0:00 [zswap-shrink]
root         144  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kworker/u3:0]
root         151  0.0  0.0      0     0 ?        I<   Jun08   0:00 [charger_manager]
root         186  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_2]
root         187  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_2]
root         188  0.0  0.0      0     0 ?        I<   Jun08   0:00 [vmw_pvscsi_wq_2]
root         189  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_3]
root         190  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_3]
root         191  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_4]
root         192  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_4]
root         193  0.0  0.0      0     0 ?        I<   Jun08   0:00 [cryptd]
root         194  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_5]
root         195  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_5]
root         201  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_6]
root         205  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_6]
root         212  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_7]
root         215  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_7]
root         216  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_8]
root         217  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_8]
root         218  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_9]
root         219  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_9]
root         221  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_10]
root         222  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_10]
root         227  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_11]
root         228  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_11]
root         230  0.0  0.0      0     0 ?        I<   Jun08   0:00 [ttm_swap]
root         231  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_12]
root         233  0.0  0.0      0     0 ?        S    Jun08   2:57 [irq/16-vmwgfx]
root         234  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_12]
root         236  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_13]
root         237  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_13]
root         238  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_14]
root         240  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_14]
root         242  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc0]
root         243  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_15]
root         244  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc1]
root         248  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_15]
root         249  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc2]
root         250  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_16]
root         251  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc3]
root         254  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_16]
root         256  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc4]
root         257  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc5]
root         259  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_17]
root         261  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_17]
root         262  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc6]
root         265  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_18]
root         266  0.0  0.0      0     0 ?        S    Jun08   0:00 [card0-crtc7]
root         268  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_18]
root         269  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_19]
root         270  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_19]
root         272  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_20]
root         274  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_20]
root         275  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_21]
root         277  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_21]
root         279  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_22]
root         280  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_22]
root         281  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_23]
root         283  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_23]
root         284  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_24]
root         285  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_24]
root         287  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_25]
root         288  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_25]
root         290  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_26]
root         292  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_26]
root         293  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_27]
root         295  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_27]
root         296  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_28]
root         297  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_28]
root         298  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_29]
root         299  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_29]
root         300  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_30]
root         301  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_30]
root         302  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_31]
root         303  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_31]
root         304  0.0  0.0      0     0 ?        S    Jun08   0:00 [scsi_eh_32]
root         305  0.0  0.0      0     0 ?        I<   Jun08   0:00 [scsi_tmf_32]
root         365  0.0  0.0      0     0 ?        I<   Jun08   0:00 [raid5wq]
root         422  0.0  0.0      0     0 ?        S    Jun08   2:08 [jbd2/sda3-8]
root         423  0.0  0.0      0     0 ?        I<   Jun08   0:00 [ext4-rsv-conver]
root         480  1.7  2.1  56208 20928 ?        S<s  Jun08 220:39 /lib/systemd/systemd-journald
root         510  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kaluad]
root         513  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kmpath_rdacd]
root         514  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kmpathd]
root         516  0.0  0.0      0     0 ?        I<   Jun08   0:00 [kmpath_handlerd]
root         518  0.0  2.7 354888 27100 ?        SLsl Jun08   4:51 /sbin/multipathd -d -s
root         521  0.0  0.6  25908  6048 ?        Ss   Jun08   0:07 /lib/systemd/systemd-udevd
systemd+     779  0.0  0.7  16132  7592 ?        Ss   Jun08   0:21 /lib/systemd/systemd-networkd
message+     862  0.0  0.5   9004  4972 ?        Ss   Jun08   0:34 @dbus-daemon --system --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only
root         867  0.0  1.8  30228 17844 ?        Ss   Jun08   0:00 /usr/bin/python3 /usr/bin/networkd-dispatcher --run-startup-triggers
root         868  0.0  0.6 234512  6500 ?        Ssl  Jun08   0:00 /usr/libexec/polkitd --no-debug
syslog       870  1.0  0.6 222404  6276 ?        Ssl  Jun08 140:23 /usr/sbin/rsyslogd -n -iNONE
root         874  0.0  0.7  15684  7744 ?        Ss   Jun08   0:15 /lib/systemd/systemd-logind
root         875  0.0  1.1 392636 11696 ?        Ssl  Jun08   0:07 /usr/libexec/udisks2/udisksd
systemd+     878  0.0  1.2  26356 12572 ?        Ss   Jun08   6:52 /lib/systemd/systemd-resolved
root         908  0.0  1.0 317976 10672 ?        Ssl  Jun08   0:00 /usr/sbin/ModemManager
root         962  0.0  2.0 107164 19984 ?        Ssl  Jun08   0:00 /usr/bin/python3 /usr/share/unattended-upgrades/unattended-upgrade-shutdown --wait-for-signal
root         990  0.1  3.2 1869848 32144 ?       Ssl  Jun08  14:21 /usr/bin/containerd
_chrony     1091  0.0  0.3  18912  3328 ?        S    Jun08   0:28 /usr/sbin/chronyd -F 1
_chrony     1094  0.0  0.0  10584   288 ?        S    Jun08   0:00 /usr/sbin/chronyd -F 1
root        1205  0.0  5.4 1953808 53796 ?       Ssl  Jun08   7:12 /usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock
root        1208  0.0  0.2   4308  2752 ?        Ss   Jun08   0:11 /usr/sbin/cron -f -P
root        1221  0.0  0.4   7672  4116 tty1     Ss   Jun08   0:00 /bin/login -p --
root        1238  0.0  0.7  15436  7208 ?        Ss   Jun08   2:54 sshd: /usr/sbin/sshd -D [listener] 0 of 10-100 startups
root        1242  0.0  0.0      0     0 ?        I<   Jun08   0:00 [wg-crypt-wg0]
root        1560  0.0  0.9  17068  9100 ?        Ss   Jun08   0:00 /lib/systemd/systemd --user
root        1561  0.0  0.2 103812  2148 ?        S    Jun08   0:00 (sd-pam)
root        1568  0.0  0.4   6088  4072 tty1     S+   Jun08   0:00 -bash
root        1817  0.0  0.8 237048  8240 ?        Ssl  Jun08   0:00 /usr/libexec/upowerd
root      247107  0.0  0.0      0     0 ?        I    12:11   0:01 [kworker/0:2-events]
root      247538  0.0  0.0      0     0 ?        I    12:38   0:01 [kworker/u2:0-events_unbound]
root      247587  0.0  1.1  17200 10984 ?        Ss   12:41   0:02 sshd: root@pts/0
root      247671  0.1  0.5   6676  5716 pts/0    Ss   12:41   0:05 -bash
root      248334  0.4  3.1 1252820 30648 ?       Ssl  12:50   0:10 /usr/lib/snapd/snapd
root      248427  0.2  0.0      0     0 ?        I    12:52   0:04 [kworker/u2:5-events_power_efficient]
root      248687  1.4  4.7 128444 46860 ?        Ssl  13:00   0:25 /opt/vpn-panel/node/venv/bin/python -m node_client.main
root      248689  0.0  1.1  17204 11236 ?        Ss   13:00   0:00 sshd: root@pts/1
root      248751  0.0  0.5   6080  5100 pts/1    Ss+  13:00   0:00 -bash
nobody    248817  0.1  3.3 1296048 33200 ?       Ssl  13:12   0:01 /usr/local/bin/xray run -config /usr/local/etc/xray/config.json
root      248818  0.0  0.0      0     0 ?        I    13:12   0:00 [kworker/u2:1-events_power_efficient]
root      248819  0.3  0.0      0     0 ?        I    13:12   0:03 [kworker/0:0-events]
root      248873  0.0  0.1   3536  1248 ?        S    13:24   0:00 nc -l 1234
root      248881  0.0  0.4   8012  4092 pts/0    S+   13:25   0:00 systemctl status vpn-node-client
root      248882  0.0  0.2   3596  2300 pts/0    S+   13:25   0:00 pager
root      248883  0.0  0.0      0     0 ?        I    13:26   0:00 [kworker/u2:2-events_unbound]
root      248897  0.0  0.0   2892   968 ?        S    13:28   0:00 /bin/sh -c ps aux
root      248898  0.0  0.3   7484  3200 ?        R    13:28   0:00 ps aux
', '', 0, NULL, 3, 18100, '127.0.0.1', '2026-06-17 16:28:38.467147+03', 200, true, '2026-06-17 16:28:38.704733+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (10, 1, 'nc -l 1234', NULL, NULL, 1, NULL, 3, 18100, '127.0.0.1', '2026-06-17 16:30:41.631101+03', 100, false, '2026-06-17 16:30:41.631101+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (11, 3, 'nc -l 1234', NULL, NULL, 1, '408, message=''Request Timeout'', url=''http://localhost:18100/api/v1/server/node/execute''', 3, 18100, '127.0.0.1', '2026-06-17 16:31:00.269668+03', 408, false, '2026-06-17 16:31:30.397297+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (12, 3, 'ping google.com', NULL, NULL, 1, '408, message=''Request Timeout'', url=''http://localhost:18100/api/v1/server/node/execute''', 2, 1, '127.0.0.1', '2026-06-17 17:09:49.727586+03', 408, false, '2026-06-17 17:10:19.853656+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (13, 3, 'ping google.com', NULL, NULL, 1, '408, message=''Request Timeout'', url=''http://localhost:18100/api/v1/server/node/execute''', 2, 1, '127.0.0.1', '2026-06-17 17:18:46.988928+03', 408, false, '2026-06-17 17:19:17.226751+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (14, 4, 'ping google.com', NULL, NULL, 1, '', 2, 1, '127.0.0.1', '2026-06-17 17:20:52.58664+03', 500, false, '2026-06-17 17:21:22.927191+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (15, 3, 'ping google.com', NULL, NULL, 1, '408, message=''Request Timeout'', url=''http://localhost:18100/api/v1/server/node/execute''', 2, 1, '127.0.0.1', '2026-06-17 17:21:37.939093+03', 408, false, '2026-06-17 17:22:08.811442+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (16, 4, 'ping google.com', NULL, NULL, 1, '', 2, 1, '127.0.0.1', '2026-06-17 17:22:20.838917+03', 500, false, '2026-06-17 17:22:50.922471+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (17, 4, 'ping google.com', NULL, NULL, 1, '', 2, 1, '127.0.0.1', '2026-06-17 17:30:08.873317+03', 500, false, '2026-06-17 17:30:38.904521+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (18, 4, 'ping google.com', NULL, NULL, 1, '', 2, 1, '127.0.0.1', '2026-06-17 17:30:43.856549+03', 500, false, '2026-06-17 17:31:13.926007+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (19, 2, 'grep', '', 'Usage: grep [OPTION]... PATTERNS [FILE]...
Try ''grep --help'' for more information.
', 2, NULL, 2, 1, '127.0.0.1', '2026-06-17 17:33:45.958808+03', 200, false, '2026-06-17 17:33:46.064436+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (20, 2, 'ls', 'README.md
node_client
requirements.txt
uninstall.sh
venv
', '', 0, NULL, 2, 1, '127.0.0.1', '2026-06-17 17:34:10.33275+03', 200, true, '2026-06-17 17:34:10.421179+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (21, 2, 'ls уыыы/', '', 'ls: cannot access ''уыыы/'': No such file or directory
', 2, NULL, 2, 1, '127.0.0.1', '2026-06-17 17:40:09.298925+03', 200, false, '2026-06-17 17:40:10.291445+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (22, 4, 'grep', NULL, NULL, 1, 'Cannot connect to host 127.0.0.1:1 ssl:default [Удаленный компьютер отклонил это сетевое подключение]', 2, 1, '127.0.0.1', '2026-06-17 17:45:24.638365+03', 500, false, '2026-06-17 17:45:26.660262+03');
INSERT INTO public.remote_execute_history OVERRIDING SYSTEM VALUE VALUES (23, 2, 'grep', '', 'Usage: grep [OPTION]... PATTERNS [FILE]...
Try ''grep --help'' for more information.
', 2, NULL, 2, 1, '127.0.0.1', '2026-06-17 17:45:59.687601+03', 200, false, '2026-06-17 17:45:59.797045+03');


--
-- TOC entry 5107 (class 0 OID 516544)
-- Dependencies: 215
-- Data for Name: sessions_admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sessions_admins VALUES ('9d353d54-04c5-4100-96bb-4ce9325c059d', 6, '2026-05-13 08:50:56.323853+03', '2026-05-13 08:51:26.323853+03', '$argon2id$v=19$m=65536,t=3,p=4$GON8D0HovRcihBAiBMB4jw$fPnXmmlAlNpWrCsx8omjyRCk5aXTjZu57HRBbx2wV2E', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', '127.0.0.1');


--
-- TOC entry 5143 (class 0 OID 517159)
-- Dependencies: 251
-- Data for Name: sub_nodes_operations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sub_nodes_operations OVERRIDING SYSTEM VALUE VALUES (1, 'add');
INSERT INTO public.sub_nodes_operations OVERRIDING SYSTEM VALUE VALUES (2, 'delete');


--
-- TOC entry 5145 (class 0 OID 517165)
-- Dependencies: 253
-- Data for Name: sub_nodes_outbox; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (500, '00000008-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser10', 2, 70, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (501, '00000009-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser11', 2, 71, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (502, '00000001-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser3', 2, 63, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (503, '00000002-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser4', 2, 64, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (504, '00000003-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser5', 2, 65, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (505, '00000004-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser6', 2, 66, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (506, '00000006-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser8', 2, 68, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (20, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 58, true, 1, '2026-05-29 09:42:25.851569+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (21, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 59, true, 1, '2026-05-29 09:47:34.781609+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (22, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 60, true, 1, '2026-05-29 09:52:12.222966+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (23, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 61, true, 1, '2026-05-29 09:53:16.404924+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (507, '00000007-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser9', 2, 69, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (508, '00000005-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser7', 2, 67, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (509, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 62, false, 2, '2026-06-04 19:21:45.055064+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (520, '00000008-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser10', 2, 70, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (521, '00000009-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser11', 2, 71, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (522, '00000001-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser3', 2, 63, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (523, '00000002-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser4', 2, 64, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (524, '00000003-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser5', 2, 65, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (525, '00000004-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser6', 2, 66, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (526, '00000006-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser8', 2, 68, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (527, '00000007-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser9', 2, 69, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (528, '00000005-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser7', 2, 67, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (529, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 62, false, 2, '2026-06-04 19:39:09.261761+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (151, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 72, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (152, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 47, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (153, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 48, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (154, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 2, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (155, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 3, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (156, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 9, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (157, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 10, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (158, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 11, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (17, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 55, true, 1, '2026-05-29 08:32:35.101446+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (18, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 56, true, 1, '2026-05-29 08:37:37.893951+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (19, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 57, true, 1, '2026-05-29 08:53:15.380865+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (159, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 12, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (160, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 13, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (161, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 14, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (162, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 15, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (163, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 16, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (164, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 17, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (165, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 18, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (166, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 19, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (167, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 20, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (168, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 21, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (169, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 22, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (170, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 23, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (171, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 24, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (172, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 25, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (173, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 26, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (174, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 52, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (175, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 53, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (176, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 54, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (177, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 56, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (178, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 58, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (179, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 60, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (180, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 62, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (181, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 27, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (182, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 28, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (183, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 29, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (184, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 30, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (185, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 31, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (186, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 32, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (187, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 33, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (188, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 34, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (189, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 35, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (190, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 36, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (191, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 37, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (192, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 38, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (193, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 39, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (194, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 40, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (195, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 41, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (196, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 42, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (197, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 43, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (198, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 44, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (199, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 45, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (200, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 46, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (201, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 49, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (202, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 50, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (203, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 51, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (204, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 55, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (205, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 57, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (206, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 59, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (207, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 61, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (208, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 72, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (209, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 47, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (210, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 48, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (211, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 2, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (212, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 3, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (213, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 9, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (214, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 10, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (215, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 11, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (216, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 12, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (217, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 13, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (218, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 14, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (219, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 15, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (220, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 16, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (221, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 17, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (222, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 18, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (223, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 19, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (224, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 20, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (225, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 21, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (226, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 22, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (227, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 23, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (228, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 24, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (229, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 25, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (230, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 26, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (231, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 52, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (232, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 53, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (233, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 54, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (234, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 56, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (235, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 58, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (236, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 60, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (238, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 27, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (239, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 28, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (240, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 29, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (241, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 30, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (242, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 31, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (243, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 32, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (244, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 33, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (245, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 34, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (246, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 35, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (247, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 36, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (248, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 37, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (249, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 38, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (250, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 39, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (251, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 40, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (252, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 41, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (253, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 42, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (254, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 43, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (255, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 44, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (256, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 45, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (257, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 46, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (258, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 49, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (259, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 50, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (260, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 51, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (261, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 55, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (262, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 57, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (263, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 59, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (264, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 61, false, 2, '2026-06-04 16:55:01.12503+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (265, '00000009-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser11', 1, 71, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (266, '00000008-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser10', 1, 70, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (267, '00000007-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser9', 1, 69, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (268, '00000006-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser8', 1, 68, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (269, '00000005-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser7', 1, 67, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (270, '00000004-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser6', 1, 66, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (271, '00000003-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser5', 1, 65, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (272, '00000002-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser4', 1, 64, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (273, '00000001-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser3', 1, 63, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (274, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 72, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (275, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 47, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (276, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 48, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (277, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 2, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (278, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 3, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (279, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 9, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (280, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 10, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (281, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 11, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (282, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 12, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (283, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 13, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (284, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 14, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (285, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 15, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (286, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 16, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (287, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 17, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (288, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 18, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (289, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 19, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (290, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 20, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (291, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 21, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (292, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 22, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (293, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 23, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (294, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 24, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (295, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 25, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (296, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 26, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (297, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 52, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (298, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 53, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (299, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 54, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (300, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 56, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (301, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 58, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (302, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 60, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (303, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 62, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (304, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 27, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (305, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 28, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (306, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 29, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (307, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 30, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (308, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 31, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (309, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 32, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (310, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 33, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (311, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 34, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (312, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 35, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (313, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 36, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (314, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 37, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (315, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 38, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (316, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 39, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (317, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 40, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (318, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 41, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (319, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 42, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (320, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 43, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (321, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 44, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (322, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 45, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (323, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 46, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (324, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 49, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (325, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 50, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (326, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 51, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (327, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 55, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (328, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 57, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (329, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 59, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (330, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 1, 61, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (340, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 72, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (341, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 47, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (342, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 48, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (343, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 2, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (344, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 3, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (345, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 9, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (346, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 10, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (347, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 11, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (348, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 12, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (349, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 13, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (350, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 14, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (351, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 15, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (352, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 16, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (353, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 17, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (354, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 18, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (355, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 19, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (356, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 20, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (357, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 21, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (358, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 22, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (359, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 23, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (360, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 24, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (361, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 25, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (362, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 26, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (363, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 52, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (364, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 53, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (365, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 54, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (366, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 56, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (367, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 58, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (368, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 60, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (370, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 27, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (371, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 28, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (372, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 29, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (373, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 30, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (374, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 31, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (375, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 32, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (376, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 33, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (377, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 34, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (378, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 35, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (379, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 36, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (380, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 37, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (381, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 38, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (382, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 39, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (383, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 40, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (384, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 41, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (385, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 42, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (386, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 43, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (387, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 44, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (388, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 45, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (389, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 46, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (390, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 49, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (391, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 50, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (392, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 51, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (393, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 55, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (394, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 57, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (395, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 59, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (396, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 61, false, 2, '2026-06-04 17:10:02.575253+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (540, '00000008-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser10', 2, 70, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (541, '00000009-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser11', 2, 71, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (542, '00000001-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser3', 2, 63, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (543, '00000002-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser4', 2, 64, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (544, '00000003-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser5', 2, 65, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (545, '00000004-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser6', 2, 66, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (546, '00000006-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser8', 2, 68, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (547, '00000007-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser9', 2, 69, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (548, '00000005-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser7', 2, 67, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (549, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 62, false, 2, '2026-06-04 19:42:36.539121+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (560, '00000008-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser10', 2, 70, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (561, '00000009-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser11', 2, 71, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (562, '00000001-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser3', 2, 63, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (563, '00000002-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser4', 2, 64, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (564, '00000003-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser5', 2, 65, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (565, '00000004-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser6', 2, 66, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (566, '00000006-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser8', 2, 68, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (567, '00000007-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser9', 2, 69, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (568, '00000005-0db0-4f10-ad0a-9c167c763c45', 'TestNodeAddUser7', 2, 67, false, 2, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.sub_nodes_outbox OVERRIDING SYSTEM VALUE VALUES (569, '33896f0d-0db0-4f10-ad0a-9c167c763c45', 'mvpALXI', 2, 62, false, 2, '2026-06-04 19:45:50.683129+03');


--
-- TOC entry 5125 (class 0 OID 516940)
-- Dependencies: 233
-- Data for Name: sub_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.sub_plans OVERRIDING SYSTEM VALUE VALUES (1, 173741824, 50000, true, 30, 'Reinar VPN', 'Отличный, Замечательный, Стабильный, Надёжный, Безопасный и т.д. @asco_hiddify_bot - продлить подписку');
INSERT INTO public.sub_plans OVERRIDING SYSTEM VALUE VALUES (2, -1, 0, NULL, NULL, 'string', NULL);


--
-- TOC entry 5137 (class 0 OID 517087)
-- Dependencies: 245
-- Data for Name: template_spec_params; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.template_spec_params OVERRIDING SYSTEM VALUE VALUES (1, 'public_key', 1);
INSERT INTO public.template_spec_params OVERRIDING SYSTEM VALUE VALUES (2, 'flow', 1);


--
-- TOC entry 5135 (class 0 OID 517074)
-- Dependencies: 243
-- Data for Name: templates_statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.templates_statuses OVERRIDING SYSTEM VALUE VALUES (1, 'Системный');
INSERT INTO public.templates_statuses OVERRIDING SYSTEM VALUE VALUES (2, 'Пользовательский');


--
-- TOC entry 5123 (class 0 OID 516929)
-- Dependencies: 231
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (1, 1252118203, 'Xm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4r9k=', 0, 'mvpALXI', '33896f0d-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (7, 1252118208, 'Xm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4r9l=', 0, 'TestNodeAddUser7', '00000005-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (5, 1252118210, 'Xm4TOw4uifQCT4wM5kmIYJJp543gg5G2HiLztei4r9k=', 0, 'TestNodeAddUser9', '00000007-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (6, 1252118209, 'Xm4TOw4uifCCT3wM5kmIYJJp543gg5G2HiLztei4r9k=', 0, 'TestNodeAddUser8', '00000006-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (8, 1252118207, 'Xm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4d9k=', 0, 'TestNodeAddUser6', '00000004-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (2, 1252118202, 'Zm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4r9k=', 0, 'mvpReinar', '44896f0d-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (9, 1252118206, 'Xm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei439k=', 0, 'TestNodeAddUser5', '00000003-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (10, 1252118205, 'Xm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4r9K=', 0, 'TestNodeAddUser4', '00000002-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (11, 1252118204, 'zm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4r9k=', 0, 'TestNodeAddUser3', '00000001-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (3, 1252118212, 'XM4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4r9k=', 0, 'TestNodeAddUser11', '00000009-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');
INSERT INTO public.users OVERRIDING SYSTEM VALUE VALUES (4, 1252118211, 'Vm4TOw4uifQCT3wM5kmIYJJp543gg5G2HiLztei4r9k=', 0, 'TestNodeAddUser10', '00000008-0db0-4f10-ad0a-9c167c763c45', 3, '2026-06-04 19:45:50.683129+03');


--
-- TOC entry 5128 (class 0 OID 517004)
-- Dependencies: 236
-- Data for Name: vnodes_sub_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.vnodes_sub_plans OVERRIDING SYSTEM VALUE VALUES (1, 2, 1);
INSERT INTO public.vnodes_sub_plans OVERRIDING SYSTEM VALUE VALUES (2, 3, 1);


--
-- TOC entry 5121 (class 0 OID 516918)
-- Dependencies: 229
-- Data for Name: whitelist_commands; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (1, 'systemctl', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (2, 'journalctl', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (4, 'ls', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (6, 'ps', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (7, 'netstat', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (8, 'ss', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (15, 'cat', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (9, 'ip', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (10, 'ping', true);
INSERT INTO public.whitelist_commands OVERRIDING SYSTEM VALUE VALUES (5, 'grep', true);


--
-- TOC entry 5159 (class 0 OID 0)
-- Dependencies: 250
-- Name: add_core_proto_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.add_core_proto_statuses_id_seq', 3, true);


--
-- TOC entry 5160 (class 0 OID 0)
-- Dependencies: 223
-- Name: node_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.node_statuses_id_seq', 2, true);


--
-- TOC entry 5161 (class 0 OID 0)
-- Dependencies: 225
-- Name: nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nodes_id_seq', 3, true);


--
-- TOC entry 5162 (class 0 OID 0)
-- Dependencies: 226
-- Name: nodes_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nodes_id_seq1', 5, true);


--
-- TOC entry 5163 (class 0 OID 0)
-- Dependencies: 246
-- Name: nodes_protocoles_spec_params_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nodes_protocoles_spec_params_values_id_seq', 23, true);


--
-- TOC entry 5164 (class 0 OID 0)
-- Dependencies: 240
-- Name: online_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.online_statuses_id_seq', 3, true);


--
-- TOC entry 5165 (class 0 OID 0)
-- Dependencies: 242
-- Name: pattern_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pattern_statuses_id_seq', 2, true);


--
-- TOC entry 5166 (class 0 OID 0)
-- Dependencies: 254
-- Name: pay_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pay_statuses_id_seq', 3, true);


--
-- TOC entry 5167 (class 0 OID 0)
-- Dependencies: 234
-- Name: payed_subs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payed_subs_id_seq', 72, true);


--
-- TOC entry 5168 (class 0 OID 0)
-- Dependencies: 238
-- Name: proto_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.proto_templates_id_seq', 8, true);


--
-- TOC entry 5169 (class 0 OID 0)
-- Dependencies: 221
-- Name: protocols_commands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.protocols_commands_id_seq', 28, true);


--
-- TOC entry 5170 (class 0 OID 0)
-- Dependencies: 219
-- Name: protocols_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.protocols_id_seq', 23, true);


--
-- TOC entry 5171 (class 0 OID 0)
-- Dependencies: 248
-- Name: remote_execute_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.remote_execute_history_id_seq', 23, true);


--
-- TOC entry 5172 (class 0 OID 0)
-- Dependencies: 252
-- Name: sub_nodes_outbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sub_nodes_outbox_id_seq', 579, true);


--
-- TOC entry 5173 (class 0 OID 0)
-- Dependencies: 232
-- Name: sub_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sub_plans_id_seq', 2, true);


--
-- TOC entry 5174 (class 0 OID 0)
-- Dependencies: 244
-- Name: template_spec_params_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.template_spec_params_id_seq', 20, true);


--
-- TOC entry 5175 (class 0 OID 0)
-- Dependencies: 217
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- TOC entry 5176 (class 0 OID 0)
-- Dependencies: 230
-- Name: users_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq1', 11, true);


--
-- TOC entry 5177 (class 0 OID 0)
-- Dependencies: 237
-- Name: vnodes_sub_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vnodes_sub_plans_id_seq', 2, true);


--
-- TOC entry 5178 (class 0 OID 0)
-- Dependencies: 228
-- Name: whitelist_commands_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.whitelist_commands_id_seq', 16, true);


--
-- TOC entry 4938 (class 2606 OID 517163)
-- Name: sub_nodes_operations add_core_proto_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_nodes_operations
    ADD CONSTRAINT add_core_proto_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4873 (class 2606 OID 516856)
-- Name: admins admins_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_login_key UNIQUE (login);


--
-- TOC entry 4889 (class 2606 OID 516827)
-- Name: node_statuses node_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.node_statuses
    ADD CONSTRAINT node_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4891 (class 2606 OID 517063)
-- Name: nodes nodes_ip_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_ip_key UNIQUE (ip);


--
-- TOC entry 4883 (class 2606 OID 516821)
-- Name: nodes_protocols nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocols
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- TOC entry 4893 (class 2606 OID 516875)
-- Name: nodes nodes_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pkey1 PRIMARY KEY (id);


--
-- TOC entry 4895 (class 2606 OID 516879)
-- Name: nodes nodes_private_ip_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_private_ip_key UNIQUE (private_ip);


--
-- TOC entry 4932 (class 2606 OID 525281)
-- Name: nodes_protocoles_spec_params_values nodes_protocoles_spec_params_valu_spec_key_id_node_proto_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocoles_spec_params_values
    ADD CONSTRAINT nodes_protocoles_spec_params_valu_spec_key_id_node_proto_id_key UNIQUE (spec_key_id, node_proto_id);


--
-- TOC entry 4934 (class 2606 OID 517108)
-- Name: nodes_protocoles_spec_params_values nodes_protocoles_spec_params_values_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocoles_spec_params_values
    ADD CONSTRAINT nodes_protocoles_spec_params_values_pkey PRIMARY KEY (id);


--
-- TOC entry 4885 (class 2606 OID 517122)
-- Name: nodes_protocols nodes_protocols_node_id_metrics_port_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocols
    ADD CONSTRAINT nodes_protocols_node_id_metrics_port_key UNIQUE (node_id, metrics_port);


--
-- TOC entry 4887 (class 2606 OID 517120)
-- Name: nodes_protocols nodes_protocols_node_id_proto_port_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocols
    ADD CONSTRAINT nodes_protocols_node_id_proto_port_key UNIQUE (node_id, proto_port);


--
-- TOC entry 4924 (class 2606 OID 517052)
-- Name: online_statuses online_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.online_statuses
    ADD CONSTRAINT online_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4926 (class 2606 OID 517078)
-- Name: templates_statuses pattern_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.templates_statuses
    ADD CONSTRAINT pattern_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4942 (class 2606 OID 525268)
-- Name: pay_statuses pay_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pay_statuses
    ADD CONSTRAINT pay_statuses_name_key UNIQUE (name);


--
-- TOC entry 4944 (class 2606 OID 525266)
-- Name: pay_statuses pay_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pay_statuses
    ADD CONSTRAINT pay_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4913 (class 2606 OID 516972)
-- Name: payed_subs payed_subs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payed_subs
    ADD CONSTRAINT payed_subs_pkey PRIMARY KEY (id);


--
-- TOC entry 4920 (class 2606 OID 517038)
-- Name: proto_templates proto_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proto_templates
    ADD CONSTRAINT proto_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4922 (class 2606 OID 517126)
-- Name: proto_templates proto_templates_title_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proto_templates
    ADD CONSTRAINT proto_templates_title_key UNIQUE (title);


--
-- TOC entry 4881 (class 2606 OID 516784)
-- Name: protocols_commands protocols_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocols_commands
    ADD CONSTRAINT protocols_commands_pkey PRIMARY KEY (id);


--
-- TOC entry 4877 (class 2606 OID 516775)
-- Name: protocols protocols_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocols
    ADD CONSTRAINT protocols_name_key UNIQUE (name);


--
-- TOC entry 4879 (class 2606 OID 516773)
-- Name: protocols protocols_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocols
    ADD CONSTRAINT protocols_pkey PRIMARY KEY (id);


--
-- TOC entry 4936 (class 2606 OID 517145)
-- Name: remote_execute_history remote_execute_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.remote_execute_history
    ADD CONSTRAINT remote_execute_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4867 (class 2606 OID 516615)
-- Name: sessions_admins sessions_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions_admins
    ADD CONSTRAINT sessions_users_pkey PRIMARY KEY (session_id);


--
-- TOC entry 4869 (class 2606 OID 516617)
-- Name: sessions_admins sessions_users_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions_admins
    ADD CONSTRAINT sessions_users_refresh_token_key UNIQUE (refresh_token);


--
-- TOC entry 4871 (class 2606 OID 516619)
-- Name: sessions_admins sessions_users_session_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions_admins
    ADD CONSTRAINT sessions_users_session_id_user_id_key UNIQUE (session_id, admin_id);


--
-- TOC entry 4940 (class 2606 OID 517170)
-- Name: sub_nodes_outbox sub_nodes_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_nodes_outbox
    ADD CONSTRAINT sub_nodes_outbox_pkey PRIMARY KEY (id);


--
-- TOC entry 4911 (class 2606 OID 516946)
-- Name: sub_plans sub_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_plans
    ADD CONSTRAINT sub_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4928 (class 2606 OID 517093)
-- Name: template_spec_params template_spec_params_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_spec_params
    ADD CONSTRAINT template_spec_params_pkey PRIMARY KEY (id);


--
-- TOC entry 4930 (class 2606 OID 517095)
-- Name: template_spec_params template_spec_params_tmp_id_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_spec_params
    ADD CONSTRAINT template_spec_params_tmp_id_key_key UNIQUE (tmp_id, key);


--
-- TOC entry 4901 (class 2606 OID 516938)
-- Name: users users_b64_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_b64_id_key UNIQUE (b64_id);


--
-- TOC entry 4875 (class 2606 OID 516645)
-- Name: admins users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4903 (class 2606 OID 516934)
-- Name: users users_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey1 PRIMARY KEY (id);


--
-- TOC entry 4905 (class 2606 OID 516936)
-- Name: users users_tg_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tg_id_key UNIQUE (tg_id);


--
-- TOC entry 4907 (class 2606 OID 516993)
-- Name: users users_tg_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tg_username_key UNIQUE (tg_username);


--
-- TOC entry 4909 (class 2606 OID 517046)
-- Name: users users_uuid_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_uuid_key UNIQUE (uuid);


--
-- TOC entry 4916 (class 2606 OID 517030)
-- Name: vnodes_sub_plans vnodes_sub_plans_node_proto_id_sub_plan_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vnodes_sub_plans
    ADD CONSTRAINT vnodes_sub_plans_node_proto_id_sub_plan_id_key UNIQUE (node_proto_id, sub_plan_id);


--
-- TOC entry 4918 (class 2606 OID 517018)
-- Name: vnodes_sub_plans vnodes_sub_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vnodes_sub_plans
    ADD CONSTRAINT vnodes_sub_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4897 (class 2606 OID 516927)
-- Name: whitelist_commands whitelist_commands_command_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whitelist_commands
    ADD CONSTRAINT whitelist_commands_command_key UNIQUE (command);


--
-- TOC entry 4899 (class 2606 OID 516924)
-- Name: whitelist_commands whitelist_commands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whitelist_commands
    ADD CONSTRAINT whitelist_commands_pkey PRIMARY KEY (id);


--
-- TOC entry 4914 (class 1259 OID 516985)
-- Name: payed_subs_sub_plan_id_user_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX payed_subs_sub_plan_id_user_id_idx ON public.payed_subs USING btree (sub_plan_id, user_id) WITH (deduplicate_items='true') WHERE (is_active = true);


--
-- TOC entry 4949 (class 2606 OID 516857)
-- Name: nodes_protocols nodes_proto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocols
    ADD CONSTRAINT nodes_proto_id_fkey FOREIGN KEY (proto_id) REFERENCES public.protocols(id) ON DELETE RESTRICT;


--
-- TOC entry 4959 (class 2606 OID 517114)
-- Name: nodes_protocoles_spec_params_values nodes_protocoles_spec_params_values_node_proto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocoles_spec_params_values
    ADD CONSTRAINT nodes_protocoles_spec_params_values_node_proto_id_fkey FOREIGN KEY (node_proto_id) REFERENCES public.nodes_protocols(id) ON DELETE CASCADE;


--
-- TOC entry 4960 (class 2606 OID 517109)
-- Name: nodes_protocoles_spec_params_values nodes_protocoles_spec_params_values_spec_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocoles_spec_params_values
    ADD CONSTRAINT nodes_protocoles_spec_params_values_spec_key_id_fkey FOREIGN KEY (spec_key_id) REFERENCES public.template_spec_params(id) ON DELETE RESTRICT;


--
-- TOC entry 4950 (class 2606 OID 516890)
-- Name: nodes_protocols nodes_protocols_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nodes_protocols
    ADD CONSTRAINT nodes_protocols_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.nodes(id) ON DELETE CASCADE;


--
-- TOC entry 4952 (class 2606 OID 525275)
-- Name: payed_subs payed_subs_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payed_subs
    ADD CONSTRAINT payed_subs_status_fkey FOREIGN KEY (status) REFERENCES public.pay_statuses(id) ON DELETE RESTRICT;


--
-- TOC entry 4953 (class 2606 OID 516975)
-- Name: payed_subs payed_subs_sub_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payed_subs
    ADD CONSTRAINT payed_subs_sub_plan_id_fkey FOREIGN KEY (sub_plan_id) REFERENCES public.sub_plans(id);


--
-- TOC entry 4954 (class 2606 OID 516980)
-- Name: payed_subs payed_subs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payed_subs
    ADD CONSTRAINT payed_subs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4957 (class 2606 OID 517080)
-- Name: proto_templates proto_templates_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proto_templates
    ADD CONSTRAINT proto_templates_status_fkey FOREIGN KEY (status) REFERENCES public.templates_statuses(id) ON DELETE RESTRICT;


--
-- TOC entry 4947 (class 2606 OID 516808)
-- Name: protocols_commands protocols_commands_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocols_commands
    ADD CONSTRAINT protocols_commands_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id);


--
-- TOC entry 4948 (class 2606 OID 516796)
-- Name: protocols_commands protocols_commands_proto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocols_commands
    ADD CONSTRAINT protocols_commands_proto_id_fkey FOREIGN KEY (proto_id) REFERENCES public.protocols(id) ON DELETE CASCADE;


--
-- TOC entry 4946 (class 2606 OID 517039)
-- Name: protocols protocols_proto_tmp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocols
    ADD CONSTRAINT protocols_proto_tmp_id_fkey FOREIGN KEY (tmp_id) REFERENCES public.proto_templates(id) ON DELETE RESTRICT NOT VALID;


--
-- TOC entry 4961 (class 2606 OID 517146)
-- Name: remote_execute_history remote_execute_history_node_proto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.remote_execute_history
    ADD CONSTRAINT remote_execute_history_node_proto_id_fkey FOREIGN KEY (node_proto_id) REFERENCES public.nodes_protocols(id);


--
-- TOC entry 4945 (class 2606 OID 516706)
-- Name: sessions_admins sessions_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions_admins
    ADD CONSTRAINT sessions_users_user_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- TOC entry 4962 (class 2606 OID 517185)
-- Name: sub_nodes_outbox sub_nodes_outbox_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_nodes_outbox
    ADD CONSTRAINT sub_nodes_outbox_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.payed_subs(id) ON DELETE CASCADE;


--
-- TOC entry 4963 (class 2606 OID 517171)
-- Name: sub_nodes_outbox sub_nodes_outbox_sub_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sub_nodes_outbox
    ADD CONSTRAINT sub_nodes_outbox_sub_node_id_fkey FOREIGN KEY (sub_node_id) REFERENCES public.vnodes_sub_plans(id) ON DELETE CASCADE;


--
-- TOC entry 4958 (class 2606 OID 517096)
-- Name: template_spec_params template_spec_params_tmp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.template_spec_params
    ADD CONSTRAINT template_spec_params_tmp_id_fkey FOREIGN KEY (tmp_id) REFERENCES public.proto_templates(id) ON DELETE CASCADE;


--
-- TOC entry 4951 (class 2606 OID 517054)
-- Name: users users_online_status_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_online_status_fkey FOREIGN KEY (online_status) REFERENCES public.online_statuses(id) ON DELETE RESTRICT NOT VALID;


--
-- TOC entry 4955 (class 2606 OID 517019)
-- Name: vnodes_sub_plans vnodes_sub_plans_node_proto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vnodes_sub_plans
    ADD CONSTRAINT vnodes_sub_plans_node_proto_id_fkey FOREIGN KEY (node_proto_id) REFERENCES public.nodes_protocols(id);


--
-- TOC entry 4956 (class 2606 OID 517024)
-- Name: vnodes_sub_plans vnodes_sub_plans_sub_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vnodes_sub_plans
    ADD CONSTRAINT vnodes_sub_plans_sub_plan_id_fkey FOREIGN KEY (sub_plan_id) REFERENCES public.sub_plans(id) ON DELETE CASCADE;


-- Completed on 2026-06-17 19:10:32

--
-- PostgreSQL database dump complete
--

\unrestrict b4sisJ0fERkDXZXTWVNaIR3GAkD2gqRxHTuHCgj8FC9ZgN4f4m6qAmdTijxcakU

