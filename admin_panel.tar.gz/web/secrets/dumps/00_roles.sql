-- создаём пользователя
CREATE ROLE reinar_crud_user WITH LOGIN PASSWORD 'VjZ0ChrfMfp9!';

-- даём доступ к БД
GRANT CONNECT ON DATABASE reinar_db TO reinar_crud_user;

-- даём доступ к схеме
GRANT USAGE ON SCHEMA public TO reinar_crud_user;

-- даём CRUD на все текущие таблицы
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO reinar_crud_user;

-- чтобы новые таблицы тоже были доступны автоматически:
ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO reinar_crud_user;