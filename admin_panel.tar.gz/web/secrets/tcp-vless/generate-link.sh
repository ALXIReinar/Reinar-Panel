#!/bin/bash

# Скрипт для генерации VLESS ссылки
# Использование: ./generate-link.sh PUBLIC_KEY

if [ -z "$1" ]; then
    echo "❌ Ошибка: не указан публичный ключ"
    echo "Использование: $0 PUBLIC_KEY"
    echo ""
    echo "Пример:"
    echo "  $0 Uxb8DZWXeNUjoAAGlkwHw34Z2wW7M4f7TTPLldc8gCo"
    exit 1
fi

PUBLIC_KEY="$1"

# URL-encode публичного ключа (на случай спецсимволов)
PUBLIC_KEY_ENCODED=$(echo -n "$PUBLIC_KEY" | jq -sRr @uri)

# Параметры
UUID="1782cc75-8af2-4d00-9d64-7e6e0da84c9a"
ADDRESS="decode-handwrite.ru"
PORT="443"
SNI="www.google.com"
SID="709c400f8da05efa"

# Генерация ссылки
VLESS_LINK="vless://${UUID}@${ADDRESS}:${PORT}?encryption=none&flow=xtls-rprx-vision&security=reality&sni=${SNI}&fp=chrome&pbk=${PUBLIC_KEY_ENCODED}&sid=${SID}&spx=%2F&type=tcp&headerType=none#VLESS-TCP-Vision"

echo "✅ VLESS ссылка сгенерирована:"
echo ""
echo "$VLESS_LINK"
echo ""
echo "📋 Скопируй эту ссылку и импортируй в свой VPN клиент"
